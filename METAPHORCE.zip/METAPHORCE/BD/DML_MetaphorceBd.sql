/************************************************
 *      DATABASE MetaphorceBd                   *
 *                                              *
 *      Data Manipulation Language (DML)        *
 ***********************************************/
 
 /*
    Version:        1.0
    Date:           17/05/2022 12:00:00
    Author:         Juana Citlalli Martínez Medina
    Email:          martinez.citlalli.aprogm@gmail.com
    Comments:       Database for management of employees 
					and contract types
 */
 
USE metaphorceBd;
 
 -- Contract types data:
INSERT INTO contractType (contractName) VALUES('Permanent');
INSERT INTO contractType (contractName) VALUES('Fixed-Term');
INSERT INTO contractType (contractName) VALUES('External');
SELECT * FROM contractType;

-- Employee data: (test)
INSERT INTO employee (employeeName, lastName, birthDate, mail, phone, employeeStatus, contractType)
VALUES ('CITLALLI', 'MARTINEZ', '2002-06-24', 'citla_mart@gmail.com', '4772337489', true, 1);
SELECT * FROM employee;