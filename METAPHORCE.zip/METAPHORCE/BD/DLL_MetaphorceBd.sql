/************************************************
 *      DATABASE MetaphorceBd                   *
 *                                              *
 *      Data Definition Language (DLL)          *
 ***********************************************/
 
 /*
    Version:        1.0
    Date:           17/05/2022 11:00:00
    Author:         Juana Citlalli Martínez Medina
    Email:          martinez.citlalli.aprogm@gmail.com
    Comments:       Database for management of employees 
					and contract types
 */
 
DROP DATABASE IF EXISTS metaphorceBd;

CREATE DATABASE metaphorceBd;

USE metaphorceBd;

--  This table stores the data of an contract type
CREATE TABLE contractType
(
    contractTypeID       INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    contractName         VARCHAR(64) NOT NULL,
    description     	 LONGTEXT NULL
);

--  This table stores the data of an employee
CREATE TABLE employee
(
    employeeID           INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    employeeName         VARCHAR(64) NOT NULL,
    lastName     		 VARCHAR(64) NOT NULL,
    birthDate            date NOT NULL,
    mail                 VARCHAR(100) NOT NULL,
    phone                VARCHAR(18) NOT NULL,
    employeeStatus       BOOLEAN NOT NULL, -- true: Active; false: Inactive
    contractType         INT NOT NULL,
    CONSTRAINT  fk_employee_contractType  FOREIGN KEY (contractType) 
	REFERENCES contractType(contractTypeID) ON DELETE CASCADE ON UPDATE CASCADE
);

DELIMITER $$
CREATE TRIGGER formatNumber
BEFORE INSERT ON employee
FOR EACH ROW
BEGIN
 SET new.phone = CONCAT('(',SUBSTRING(new.phone,1,2),') ',SUBSTRING(new.phone,3,2),' ',SUBSTRING(new.phone,5,2),'-',SUBSTRING(new.phone,7,2),'-',SUBSTRING(new.phone,9,2));
END$$
DELIMITER ;