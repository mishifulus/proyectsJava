/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.metaphorce.humanresources.model;

/**
 *
 * @author marti
 */
public class ContractType {
    
    private int contractTypeID;
    private String contractName;
    private String description;

    public ContractType() {
    }

    public ContractType(String contractName, String description) {
        this.contractName = contractName;
        this.description = description;
    }

    public ContractType(int contractTypeID, String contractName, String description) {
        this.contractTypeID = contractTypeID;
        this.contractName = contractName;
        this.description = description;
    }

    public int getContractTypeID() {
        return contractTypeID;
    }

    public void setContractTypeID(int contractTypeID) {
        this.contractTypeID = contractTypeID;
    }

    public String getContractName() {
        return contractName;
    }

    public void setContractName(String contractName) {
        this.contractName = contractName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    
}
