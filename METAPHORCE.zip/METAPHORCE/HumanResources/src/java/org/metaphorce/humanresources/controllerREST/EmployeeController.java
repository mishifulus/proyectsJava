/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.metaphorce.humanresources.controllerREST;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.metaphorce.humanresources.model.Employee;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.metaphorce.humanresources.db.ConectionBD;
import org.metaphorce.humanresources.model.ContractType;

/**
 *
 * @author marti
 */
@RestController
public class EmployeeController {
    
    @GetMapping("/employee/showActiveEmployees")
    public List<Employee> showActiveEmployees() throws Exception
    {
        String query = "SELECT * FROM employee WHERE employeeStatus = true;";
        
        List<Employee> employees = new ArrayList<Employee>();
        
        Employee e = null;
        
        ConectionBD connMySQL = new ConectionBD();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(query);
        
        ResultSet rs = pstmt.executeQuery();
        
        if(rs.next())
        {
            e = fill(rs);
            employees.add(e);
        }
        
        rs.close();
        pstmt.close();
        connMySQL.close();
        
        return employees;
    }
    
    private Employee fill(ResultSet rs) throws SQLException
    {
        Employee e = new Employee();
        ContractType ct = new ContractType();
        
        ct.setContractTypeID(rs.getInt("contractTypeID"));
        ct.setContractName(rs.getString("contractName"));
        ct.setDescription(rs.getString("description"));
        
        e.setEmployeeID(rs.getInt("employeeID"));
        e.setEmployeeName(rs.getString("employeeName"));
        e.setLastName(rs.getString("lastName"));
        e.setBirthDate(rs.getString("birthDate"));
        e.setMail(rs.getString("mail"));
        e.setPhone(rs.getString("phone"));
        e.setEmployeeStatus(rs.getBoolean("employeeStatus"));
        e.setContractType(ct);
        
        return e;
    }
    
    @GetMapping("/employee/showEmployeeID")
    public Employee showEmployeeID(String folio) throws Exception
    {
        String query = "SELECT * FROM employee WHERE employeeID = '"+ folio+"';";
        
        Employee e = null;
        
        ConectionBD connMySQL = new ConectionBD();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(query);
        
        ResultSet rs = pstmt.executeQuery();
        
        if(rs.next())
        {
            e = fill(rs);
        }
        
        rs.close();
        pstmt.close();
        connMySQL.close();
        
        return e;
    }
    
    @GetMapping("/employee/insertEmployee")
    public int insertEmployee(Employee e) throws Exception
    {
        String query = "INSERT INTO employee(employeeName, lastName, birthDate,mail,phone,employeeStatus,contractType)"
                + "VALUES(?,?,?,?,?,?,?);";
        int idGenerado = -1;
        
        ConectionBD connMySQL = new ConectionBD();
        Connection conn = connMySQL.open();
        
        PreparedStatement ps = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
        
        ps.setString(1, e.getEmployeeName());
        ps.setString(2, e.getLastName());
        ps.setString(3, e.getBirthDate());
        ps.setString(4, e.getMail());
        ps.setString(5, e.getPhone());
        ps.setBoolean(6, e.isEmployeeStatus());
        ps.setInt(7, e.getContractType().getContractTypeID());
        
        ResultSet rs = null;
        ps.executeUpdate();
        rs = ps.getGeneratedKeys();
        
        if (rs.next())
        {
            idGenerado = rs.getInt(1);
            e.setEmployeeID(idGenerado);
        }
        
        rs.close();
        ps.close();
        connMySQL.close();
        
        return idGenerado;
    }
    
    @GetMapping("/employee/updateEmployee")
    public void updateEmployee(Employee e) throws Exception
    {
        String query = "UPDATE employee SET employeeName = ?, lastName = ?, birthDate = ?,mail = ?,phone = ?,employeeStatus = ?,contractType = ? WHERE employeeID = "+e.getEmployeeID()+";";
        
        ConectionBD connMySQL = new ConectionBD();
        Connection conn = connMySQL.open();
        PreparedStatement ps = conn.prepareStatement(query);
        
        ps.setString(1, e.getEmployeeName());
        ps.setString(2, e.getLastName());
        ps.setString(3, e.getBirthDate());
        ps.setString(4, e.getMail());
        ps.setString(5, e.getPhone());
        ps.setBoolean(6, e.isEmployeeStatus());
        ps.setInt(7, e.getContractType().getContractTypeID());
        
        ps.executeUpdate();
        ps.close();
        connMySQL.close();
    }
    
    @GetMapping("/employee/deleteEmployee")
    public void deleteEmployee(Employee e) throws Exception
    {
        String query = "UPDATE employee SET employeeStatus = false WHERE employeeID="+e.getEmployeeID()+";";
        
        ConectionBD connMySQL = new ConectionBD();
        Connection conn = connMySQL.open();
        PreparedStatement ps = conn.prepareStatement(query);
        ps.executeUpdate();
        
        ps.close();
        connMySQL.close();
    }
}
