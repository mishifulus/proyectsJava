/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.metaphorce.humanresources.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author marti
 */
public class ConectionBD {
    Connection conexion;
    
    public Connection open() throws Exception
    {
        //Establecer el friver con el que se va a trabajar
        String driver = "com.mysql.jdbc.Driver"; //Está en la libreria de MySQL Connection
        //Establecer la ruta de conexión
        String url = "jdbc:mysql://127.0.0.1:3306/help_desk";
        //Establecer los valores para los permisos de acceso
        String user = "root";
        String password = "CITLALLI123";
        
        //Damos de alta el uso del driver
        Class.forName(driver);
        
        //Abrimos la conexión
        conexion = DriverManager.getConnection(url, user, password);
        
        //Retornamos la conexión que se ha ceado y abierto
        return conexion;
    }
    
    public void close()
    {
        try {
            if (conexion != null)
                conexion.close();
            } 
        catch (SQLException ex) 
            {
                ex.printStackTrace();
            }
    }
}
