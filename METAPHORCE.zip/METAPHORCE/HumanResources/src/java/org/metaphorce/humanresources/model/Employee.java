/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.metaphorce.humanresources.model;

/**
 *
 * @author marti
 */
public class Employee {
    
    private int employeeID;
    private String employeeName;
    private String lastName;
    private String birthDate;
    private String mail;
    private String phone;
    private boolean employeeStatus;
    private ContractType contractType;

    public Employee() {
    }

    public Employee(String employeeName, String lastName, String birthDate, String mail, String phone, boolean employeeStatus, ContractType contractType) {
        this.employeeName = employeeName;
        this.lastName = lastName;
        this.birthDate = birthDate;
        this.mail = mail;
        this.phone = phone;
        this.employeeStatus = employeeStatus;
        this.contractType = contractType;
    }

    public Employee(int employeeID, String employeeName, String lastName, String birthDate, String mail, String phone, boolean employeeStatus, ContractType contractType) {
        this.employeeID = employeeID;
        this.employeeName = employeeName;
        this.lastName = lastName;
        this.birthDate = birthDate;
        this.mail = mail;
        this.phone = phone;
        this.employeeStatus = employeeStatus;
        this.contractType = contractType;
    }

    public int getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(int employeeID) {
        this.employeeID = employeeID;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public boolean isEmployeeStatus() {
        return employeeStatus;
    }

    public void setEmployeeStatus(boolean employeeStatus) {
        this.employeeStatus = employeeStatus;
    }

    public ContractType getContractType() {
        return contractType;
    }

    public void setContractType(ContractType contractType) {
        this.contractType = contractType;
    }
}
