/************************************************
 *      DATABASE MetaphorceBd                   *
 *                                              *
 *      Data Manipulation Language (DML)        *
 ***********************************************/
 
 /*
    Version:        1.0
    Date:           17/05/2022 12:00:00
    Author:         Juana Citlalli Martínez Medina
    Email:          martinez.citlalli.aprogm@gmail.com
    Comments:       Database for management of employees 
					and contract types
 */
 
USE metaphorceBd;
 
 -- Contract types data:
INSERT INTO contractType (contractName) VALUES('Permanent');
INSERT INTO contractType (contractName) VALUES('Fixed-Term');
INSERT INTO contractType (contractName) VALUES('External');